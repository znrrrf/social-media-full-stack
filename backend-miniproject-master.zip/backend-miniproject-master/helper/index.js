const transporter = require("./transporter");


module.exports = {
    transporter
}