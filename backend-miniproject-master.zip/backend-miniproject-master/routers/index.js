const userRouters = require("./userRouters");
const authRouters = require("./authRouters");
const contentRouters = require('./contentRouters')

module.exports = {
    userRouters, authRouters, contentRouters
}